These screenshots are only an example of what the basic interface could look like at various points. You can design your interface to look differently as long as the functionality meets the requirements.

NOTE: The checkmarks are an example meeting the imageview requirement and of extra credit (since they give better feedback to the user).
