enum GameDirection {
    case north, east, west, south
}

struct GameLocation {
    let x: Int
    let y: Int
    let allowedDirections: [GameDirection] //allowedDirections is an array of possiblities N/E/S/W
    var event: String?
}

struct GameRow {
    let locations: [GameLocation] //locations is an array of GameLocation structs
}

class GameModel {
    
    private var currentRowIndex = 2          // start at (x: 0, y: 0)
    private var currentLocationIndex = 2     // which translates to index 2 in our arrays
    
    private var gameGrid: [GameRow] = [] //make the gameGrid, an array of GameRows
    
    init() {
        self.gameGrid = createGameGrid()
    }

    func restart() {
        currentRowIndex = 2
        currentLocationIndex = 2
    }
    
    func move(direction: GameDirection) {
        switch direction {
        case .north:    currentRowIndex += 1
        case .south:    currentRowIndex -= 1
        case .east:     currentLocationIndex += 1 //columnIndex
        case .west:     currentLocationIndex -= 1 //columnIndex
        }
    }
    
    var currentLocation: GameLocation {
        //return the *correct* GameLocation struct in the gameGrid for the player's current location.
        let x: GameLocation
        let y: GameRow
        y = gameGrid[currentRowIndex]
        x = y.locations[currentLocationIndex]
        
        return x
        
        //allowedDirectionsForCoordinate(x: currentRowIndex, y: currentLocationIndex)
        //eventForCoordinate(x: x, y: y)
        //return GameLocation(x: x, y: y, allowedDirections: [], event: eventForCoordinate(x: currentRowIndex, y: currentLocationIndex))
    }
    
    // MARK: Helper methods for creating the game grid

    private func eventForCoordinate(x: Int, y: Int) -> String? {
        //Implement at least 2 special events for specific coordinates in this method.
        if x == 2 && y == 2 {
            print("RACE CONDITION")
            return "RACE CONDITION"
            //eventLabel.text = "Moved South!"
        }
        if x == -2 && y == -1 {
            print ("Race CONDITION")
        }
        
        return nil
    }
    
    private func createGameGrid() -> [GameRow] {
        var gameGrid = [GameRow]() //makes gameGrid with array of GameRow
        for yValue in -2...2 { //setting y boundaries... should this be 0... 4?
            var locations = [GameLocation]() //locations is an array of GameLocation structs
            for xValue in -2...2 { //checking all x values... should this be 0... 4?
                let directions = allowedDirectionsForCoordinate(x: xValue, y: yValue)
                let event = eventForCoordinate(x: xValue, y: yValue)
                let location = GameLocation(x: xValue, y: yValue, allowedDirections: directions, event: event)
                locations.append(location)
            }
            let gameRow = GameRow(locations: locations)
            gameGrid.append(gameRow)
        }
        return gameGrid
    }
    
    //this function is given an x and y, and returning a GameDirection object which is
    private func allowedDirectionsForCoordinate(x: Int, y: Int) -> [GameDirection] {
        var directions = [GameDirection]()
        
        switch y {
        case -2:    directions += [.north] //when y is -2 allowed y direction is only north
        case 2:     directions += [.south] //when y is 2 allowed y direction is only south
        default:    directions += [.north, .south] //when y is not 2 or -2 the north and south buttons are options
        }
        switch x {
        case -2:    directions += [.east] //when x is -2 allowed x direction is only east
        case 2:     directions += [.west] //when x is 2 allowed x direction is only west
        default:    directions += [.east, .west] //when x is not 2 or -2 the east and west buttons are options
        }
        
        return directions //returns array of north/east/west/south
    }
}
