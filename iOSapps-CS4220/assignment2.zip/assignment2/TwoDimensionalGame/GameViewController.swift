import UIKit

class GameViewController: UIViewController {
    @IBOutlet weak var eventLabel: UILabel!
    @IBOutlet weak var locationLabel: UILabel!
    
    let gameModel = GameModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    @IBAction func restartButton(_ sender: Any) {
        gameModel.restart()
    }
    
    @IBAction func southButton(_ sender: UIButton) {
        gameModel.move(direction: .south)
        eventLabel.text = "Moved South!"
        locationLabel.text = "gameModel.currentLocation.x; gameModel.currentLocation.y" //THIS IS NOT CORRECT but update location label
        
    }
    @IBAction func eastButton(_ sender: UIButton) {
        gameModel.move(direction: .east)
        eventLabel.text = "Moved East!"
    }
    @IBAction func northButton(_ sender: UIButton) {
        gameModel.move(direction: .north)
        eventLabel.text = "Moved North!"
    }
    @IBAction func westButton(_ sender: UIButton) {
        gameModel.move(direction: .west)
        eventLabel.text = "Moved West!"
    }
    
}

