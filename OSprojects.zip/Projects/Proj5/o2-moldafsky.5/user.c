#include <stdio.h> //input output
#include <stdlib.h> //for exit
#include <sys/ipc.h> // shared memory
#include <sys/shm.h> // shared memory
#include <signal.h> //signal handling
#include <sys/types.h> // for wait
#include <sys/wait.h> // for wait and kill
#include <string.h> //memset

struct mesg_buffer {
        long mesg_type;
        int pid;
        int release;
        int request;
	int terminate;
} message;

struct shm{
        int clock[2];
        int resources [20]; // amount of each resource that exists
        int allocated [18][20]; // where the resources are allocated
        int max[18]; // max amount a resource a process could request
        int request[18]; //aligns with pidArr holds value of requested resource
	int pidArr[18]; // process array
	int available[20]; //how many resources are left
	int blockTime[2];
}sharedmem;

struct shm *shared; // shared memory struct

int findPid(int pid);

void timeConvert(int clock[]);

//signal handler
void sigHandler(int signo);


int main(int argc, char *argv[]){
	
	//variables
	int shmid; // id of shared memory
	int msid; //message id
	key_t shmkey = ftok("oss", 53); // key for shared memory
        key_t mskey = ftok("oss", 51); // generate key for crit sec
	time_t t; //for time seeding
	int i;
	int clock[2];

	//signal handler
	if (signal(SIGINT, sigHandler) == SIG_ERR)
                perror("oss: can't catch SIGINT");
        if (signal(SIGALRM, sigHandler) == SIG_ERR)
                perror("master: can't catch SIGALRM");

	//seed
	srand((unsigned) time(&t)+ getpid());

	//get shared memory
	if((shmid = shmget(shmkey, (sizeof(sharedmem)), 0666)) == -1){
                perror("user: Error: shmget failed");
                return 1;
        }

	//access message queue
	msid = msgget(mskey, 0666);

	//attach shared memory
	shared =  shmat(shmid, NULL, 0);

	while(1){
		
		message.pid = getpid();
		i = findPid(getpid());
		message.release = 0;
		message.request = 0;	
		message.terminate = 0;		

		//terminate?
		if((rand() % 75 + 1)  == 5){
                        int j;
                        memset((*shared).allocated[i], 0, 20*sizeof(int));
                        message.mesg_type =2;
			message.terminate = 1;
                        if(msgsnd(msid, &message, sizeof(message), 0) == -1){
                                perror("user: Error: msgsnd");
                        }
			return 0;
                }

		// request resource or release
		if((rand() % 3 + 1)  == 3){
		//request
			if((rand() % 10)+1 > 3){
				//check if resource is at max claims 
				message.request = rand() % 20 + 1;
				if((*shared).allocated[i][message.request-1]+1 > (*shared).max[i]){
					message.request = 0;
				}else{
					//send request
					message.mesg_type =2;
					if(msgsnd(msid, &message, sizeof(message), 0) == -1){
                			        perror("user: Error: msgsnd");
			                }
					
					clock[0] = (*shared).clock[0];
					clock[1] = (*shared).clock[1];

					msgrcv(msid, &message, sizeof(message), getpid(), 0);
					if((*shared).clock[1] > 0){
						(*shared).clock[1] -= 1;
						(*shared).clock[0] += 1000000000;
					}
					(*shared).blockTime[0] += (*shared).clock[0] - clock[0];
					(*shared).blockTime[1] += (*shared).clock[1] - clock[1];
					timeConvert((*shared).blockTime);
					timeConvert((*shared).clock);
				}
			//release
			} else{
				//randomly release resource
				int j;
				int cnt = 0;
				int random[20];
				memset(random, 0, 20*sizeof(int));
				for(j = 0; j < 20; j++){
					if((*shared).allocated[i][j] != 0){
						random[cnt] = j;
						cnt++;
					}
				}

				if (cnt != 0){
					int roll = rand() % cnt;
					message.release = random[roll]+1;
					message.mesg_type = 2;
					if(msgsnd(msid, &message, sizeof(message), 0) == -1){
                                        	perror("user: Error: msgsnd");
                                	}

					msgrcv(msid, &message, sizeof(message), getpid(), 0);
				}
			}
	        }
	
	}


	return 0;


}

void timeConvert(int clock[]){
        clock[1] += clock[0]/1000000000;
        clock[0] = clock[0]%1000000000;
}



int findPid(int pid){
        int i;
        for(i = 0; i <18; i++){
                if((*shared).pidArr[i] == pid){
                        return i;
                }
        }
}

void sigHandler(int signo){
        if (signo == SIGINT || signo == SIGALRM){
		fprintf(stderr, "%i \n", getpid());
                exit(0);
        }
}

