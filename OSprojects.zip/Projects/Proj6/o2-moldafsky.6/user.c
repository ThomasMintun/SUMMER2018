#include <stdio.h>
#include <sys/ipc.h> // shared memory
#include <sys/shm.h> // shared memory
#include <signal.h> //signal handling
#include <time.h> // for setperiodic
#include <stdlib.h> //for exit


struct mesg_buffer {
        long mesg_type;
        int pid;
}message;

struct procBlock{
	int procSize; //size of process
        int pid; //proc pid
        int mem[32]; // memory table
        int request; //requested memory
        char op;//attempted operation of program
                // t - terminate
                // r - read
                // w - write
};                                

struct memory{
        char reference; // reference bit
        char occupy; // occupied or not
};

struct shared{
        int clock[2];
        struct memory pageTable [256];
	struct procBlock proc[18];
}sharedmem;

//Global vars
key_t shmkey; // key for shared memory
int shmid; // id of shared memory
key_t mskey; //message key
int msid; //message id
struct shared *shm; // shared memory struct


//signal handler
void sigHandler(int signo);

//find pid in pidArr
int findPid(int pid);

int main(int argc, char **argv){

	//vars
	time_t t; //for time seeding
	shmkey = ftok("oss", 65); // key for shared memory
        mskey = ftok("oss", 64); // generate key for crit sec
	int i;	
	
	if (signal(SIGINT, sigHandler) == SIG_ERR)
                perror("oss: can't catch SIGINT");

	//seed random generator
	srand((unsigned) time(&t) + getpid());

	//get shared memory
	if((shmid = shmget(shmkey, (sizeof(sharedmem)), 0666)) == -1){
                perror("user: Error: shmget failed");
                return 1;
        }

	//access message queue
	msid = msgget(mskey, 0666);

	//attach shared memory
	shm =  shmat(shmid, NULL, 0);

	i = findPid(getpid());

	int j;
	for(j = 0; j <32; j ++){
		(*shm).proc[i].mem[j] = -1;
	}

	(*shm).proc[i].procSize = (rand() % 32000) + 1;

	//main loop
	while(1){
		message.pid = getpid();
		(*shm).proc[i].op = 0;


		//Terminate?
		if(((rand() % 5000) + 1) == 50){
			(*shm).proc[i].op = 't';
			message.mesg_type = 1;
                	if(msgsnd(msid, &message, sizeof(message), 0) == -1){
                		perror("user: Error: msgsnd");
                	}
			break;
		}

		//read of write	
		if(((rand() % 5) + 1) == 5){

			(*shm).proc[i].request = (rand() % ((*shm).proc[i].procSize) + 100) +1;
			if((*shm).proc[i].request > (*shm).proc[i].procSize){
				message.mesg_type = 1;
                        	if(msgsnd(msid, &message, sizeof(message), 0) == -1){
                                	perror("user: Error: msgsnd");
                        	}
				break;
			}

			if(((rand() % 4) + 1) == 4){
				(*shm).proc[i].op = 'w';
                        }else{
				(*shm).proc[i].op = 'r';
			}

			message.mesg_type = 1;
                        if(msgsnd(msid, &message, sizeof(message), 0) == -1){
                                perror("user: Error: msgsnd");
			}

			msgrcv(msid, &message, sizeof(message), getpid(), 0);
		}

	}

	return 0;
}


void sigHandler(int signo){
        if (signo == SIGINT){
                exit(0);
        }
}

int findPid(int pid){
        int i;
        for(i = 0; i <18; i++){
                if((*shm).proc[i].pid == pid){
                        return i;
                }
        }
}

