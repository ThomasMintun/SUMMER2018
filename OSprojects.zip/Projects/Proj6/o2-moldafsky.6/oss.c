#include <stdio.h> //input stdout
#include <stdlib.h> //for exit
#include <sys/ipc.h> // shared memory
#include <sys/shm.h> // shared memory
#include <unistd.h> // execl
#include <signal.h> //signal handling
#include <sys/types.h> // for wait
#include <sys/wait.h> // for wait and kill
#include <time.h> // for setperiodic
#include <string.h> // for memset
#define BILLION 1000000000L //for setperiodic


struct mesg_buffer {
	long mesg_type;
        int pid;
}message;

struct procBlock{
	int procSize; //size of process
	int pid; //proc pid
	int mem[32]; // memory table
	int request; //requested memory
	char op;//attempted operation of program
		// t - terminate
		// r - read
		// w - write
}PB;

struct memory{
	char reference; // reference bit 
	char occupy; // occupied or not
};

struct shared{
	int clock[2];
	struct memory pageTable [256];
	struct procBlock proc[18];
}sharedmem;


//global variables
FILE *action; //action stream
key_t shmkey; // key for shared memory
int shmid; // id of shared memory
key_t mskey; //message key
int msid; //message id
struct shm *shared; // shared memory struct
int line = 0; //track file size
struct shared *shm; // shared memory struct
int prCount = 0; //current procs in system
int prMax = 18; //max procs allowed
int blocked[18]; //sused process 
int sus[2]; //time when memory fetch will be complete
int mempointer = 0; //memory address pointer for page table
int memAcc = 0; //how many times memory was accessed
int prTot = 0;
int pfault = 0;
int segs = 0;

//terminates program
void terminator();

//signal handler
void sigHandler(int signo);

//convert nanoseconds to seconds
void timeConvert(int clock[]);

//countdown taken from book
static int setperiodic(double sec);

//spawn processes
void spawn();

//reset a timer
void timerReset(int timer[], int bottom, int range);

//find pid in pidArr
int findPid(int pid);

void printState();

//deal with terminated process
void terminate(int i);

//deal wioth memory accessMemes
void accessMem(int i);

//check to see if all procs are waiting
void checkBlocked(int time []);

//complete fetching memory from hard disk
void fetch();

//operations for queueing
void enqueue(int queue[], int pid);
void dequeue(int queue[]);

int main(int argc, char *argv[]){

	int opt;
        while((opt = getopt (argc, argv, "h")) != -1)
                switch (opt){
                        case 'h':
                                printf("Program spawns user children, uses some shared memory, and message queues.\n");
                                printf("Program will write to and create file action.log \n");
                                printf("Program can take one optional argument that limits amount of concurrent processes. \n");
                                return 0;
                                break;}

	//handle arguments
	if(argc > 1){
		if(atoi(argv[1]) < 0 || atoi(argv[1]) > 18){
			perror("testsim: Error: Arguments must be integer greater than 0 and less than 18. Setting to default: 18");
		}else{
			prMax = atoi(argv[1]);
		}
	}

	//variables
	time_t t; //for time seeding
        int spawnTime[2] ={ 0, 0}; // time when to spawn more processes
        shmkey = ftok("oss", 65); // key for shared memory
        mskey = ftok("oss", 64); // generate key for crit sec
        int closed = 0;
        int i;
	int stat = 0;


	//signal handler
	if (signal(SIGINT, sigHandler) == SIG_ERR)
                perror("oss: can't catch SIGINT");
        if (signal(SIGALRM, sigHandler) == SIG_ERR)
                perror("master: can't catch SIGALRM");
        if (signal(SIGSEGV, sigHandler) == SIG_ERR)
                perror("master: can't catch SIGSEGV");

	//set timer
	if (setperiodic(2) == -1) {
                perror("Failed to setup termination timer");
                return 1;
        }

	//seed random generator
	srand((unsigned) time(&t) + getpid());

	//Open file for stdout
	if(!(action = fopen("action.log", "a"))){
                perror("oss: Error: unable to open action.log");
        }

	//create message queue
	if((shmid = shmget(shmkey, (sizeof(sharedmem)), IPC_CREAT | 0666)) == -1){
                perror("oss: Error: shmget failed");
                return 1;
        }

	//create message queue
	if ((msid = msgget(mskey, IPC_CREAT | 0666)) == -1){
                perror("oss: Error: msgget");
                return 1;
        }

	//attach shared memory
	shm  =  shmat(shmid, NULL, 0);

	int j;
	for(j = 0; j <256; j++){
		(*shm).pageTable[j].occupy = '.';
		(*shm).pageTable[j].reference = '.';
	}


	//main loop
	while(1){
	
		if(prTot >= 100){
			terminator();	
			return 0;
		}
		//action shutdown
		if(line >= 100000 && closed == 0){
        		closed = 1;
        		fclose(action);  
        	}

		// check for process
		int empty = 0;
		int k;
                for(k = 0; k < prMax; k++){
                        if((*shm).proc[k].pid != 0){
                                empty = 1;
                                break;
                        }
                }

		//advance clock if no processes
		if(empty == 0){
                        (*shm).clock[0] = spawnTime[0];
                        (*shm).clock[1] = spawnTime[1];
                }


		// spawn process
	 	if(((*shm).clock[1] == spawnTime[1] && (*shm).clock[0] >= spawnTime[0]) || (*shm).clock[1] > spawnTime[1]){
			spawn();
			timerReset(spawnTime, 1000000, 400000000 );	
			fprintf(action, "OSS: Will attempt to spawn new process at %i:%09i \n", spawnTime[1], spawnTime[0]);
                	fflush(action);
			line++;
		}


		//deal with queued requests
		checkBlocked(sus);
		if(((*shm).clock[1] == sus[1] && (*shm).clock[0] >= sus[0]) || (*shm).clock[1] > sus[1]){
			if(blocked[0] != 0){
				fetch();
			}
		}
	

		//rcv messages from children
		msgrcv(msid, &message, sizeof(message), 1, 0);

		i = findPid(message.pid);		

		//handle memory request 
		if((*shm).proc[i].request > (*shm).proc[i].procSize){
			fprintf(action, "Process %i seg faulted and is being terminated. \n", message.pid);
			fflush(action);
			line++;
			segs++;
			(*shm).proc[i].op = 't';
		}else{
			(*shm).proc[i].request = (*shm).proc[i].request/1000;
		}

		//if proc terminated 
		if ((*shm).proc[i].op == 't'){
			terminate(i);
		}

		//if memory accessMem
		if((*shm).proc[i].op == 'r' || (*shm).proc[i].op == 'w'){
			accessMem(i);

		}
		
		
		//(*shm).clock[0] += 10000000;
		timeConvert((*shm).clock);
		if(stat <= (*shm).clock[1]){
			printState();
			stat++;
		}
	}
	


	return 0;
}


void fetch(){
	int i = findPid(blocked[0]);

	/*fprintf(action, "OSS: completed fetching memory for process %i at %i:%09i.\n", (*shm).proc[i].pid, (*shm).clock[1], (*shm).clock[0]);
        fflush(action);
        line++;*/

	while(1){
		if((*shm).pageTable[mempointer].occupy  == '.' || (*shm).pageTable[mempointer].reference == '0'){
			memAcc++;
			if( (*shm).pageTable[mempointer].occupy == 'D'){
                                (*shm).clock[0] += 1000;
                                timeConvert((*shm).clock);
				fprintf(action, "OSS: Writing over dirty page. transfering old memory to disk.\n");
        			fflush(action);
        			line++;
                        }

			if((*shm).proc[i].op == 'w'){
				(*shm).pageTable[mempointer].occupy = 'D';
			}else if((*shm).proc[i].op == 'r'){
				(*shm).pageTable[mempointer].occupy = 'U';
			}
			(*shm).pageTable[mempointer].reference = '1';
			(*shm).proc[i].mem[(*shm).proc[i].request] = mempointer;
			mempointer++;
		        if (mempointer >=256){
                        	mempointer  = 0;
			}
			break;
		}

		(*shm).pageTable[mempointer].reference = '0';

		mempointer++;
		if (mempointer >=255){
			mempointer  = 0;
		}

	}

	message.mesg_type = blocked[0];
	if(msgsnd(msid, &message, sizeof(message), 0) == -1){
                 perror("user: Error: msgsnd");
        }
	dequeue(blocked);
	timerReset(sus, 14000000, 2000000);
}


void accessMem(int i){

	//if there is a page fault
	if ((*shm).proc[i].mem[(*shm).proc[i].request] == -1){
		/*fprintf(action, "OSS: page fault when process %i tried to access its  %iK of memory at %i:%09i.\n", (*shm).proc[i].pid, (*shm).proc[i].request, (*shm).clock[1], (*shm).clock[0]);
                        fflush(action);
                        line++;*/
		pfault++;
		enqueue(blocked, (*shm).proc[i].pid);

	}else{
		memAcc++;
		//memory read
		if((*shm).proc[i].op == 'r'){
			/*fprintf(action, "OSS: process %i accessed its %iK of memory at %i:%09i.\n", (*shm).proc[i].pid, (*shm).proc[i].request, (*shm).clock[1], (*shm).clock[0]);
        		fflush(action);
        		line++;*/
			(*shm).clock[0] += 10;
			timeConvert((*shm).clock);
			(*shm).pageTable[(*shm).proc[i].mem[(*shm).proc[i].request]].reference = '1';
			(*shm).proc[i].op = 0;

		//memory write
		}else if((*shm).proc[i].op == 'w'){
			/*fprintf(action, "OSS: process %i accessed its %iK of memory at %i:%09i.\n", (*shm).proc[i].pid, (*shm).proc[i].request, (*shm).clock[1], (*shm).clock[0]);
                        fflush(action);
                        line++;*/
			(*shm).clock[0] += 10;
                        timeConvert((*shm).clock);
			(*shm).pageTable[(*shm).proc[i].mem[(*shm).proc[i].request]].reference = '1';
			(*shm).pageTable[(*shm).proc[i].mem[(*shm).proc[i].request]].occupy = 'D';
			(*shm).proc[i].op = 0;
		}

		message.mesg_type = message.pid;
	        if(msgsnd(msid, &message, sizeof(message), 0) == -1){
                	 perror("user: Error: msgsnd");
       		}


	}
}

void checkBlocked(int time []){
	int j;
	int k = 0;
        for(j = 0; j<prMax; j++){
        	if(blocked[j] != 0){
                	k++;
                }
        }
		
	//if queue is all blocked forward time
        if(prCount == k){
		(*shm).clock[0] = time[0];
		(*shm).clock[1] = time[1];
	}
}


void terminate(int i){
	while(waitpid(-1, NULL, WNOHANG) > 0);
        fprintf(action, "OSS: process %i terminated and released its resources at %i:%09i.\n", message.pid, (*shm).clock[1], (*shm).clock[0]);
        fflush(action);
        line++;
	
	int j;
	for(j = 0; j <32; j++){
		if((*shm).proc[i].mem[j] != -1){
			if( (*shm).pageTable[(*shm).proc[i].mem[j]].occupy == 'D'){
				(*shm).clock[0] += 1000;
				timeConvert((*shm).clock);
				fprintf(action, "      OSS: Removing dirty page from memory. transfering old memory to disk.\n");
                                fflush(action);
                                line++;

			}
			(*shm).pageTable[(*shm).proc[i].mem[j]].reference = '.';
			(*shm).pageTable[(*shm).proc[i].mem[j]].occupy = '.';
		}
	}

        prCount--;
      	(*shm).proc[i].pid = 0;
       	(*shm).proc[i].op = 0;

}


void dequeue(int queue[]){
	int j;
        for(j = 0; j < prMax-1; j++){
                queue[j] = queue[j+1];
        }
        queue[j] = 0;
}


void enqueue(int queue[], int pid){
        int j;
        for(j = 0; j < prMax; j++){
                if (queue[j] == 0 ){
                        queue[j] = pid;
                        break;
                }
        }

	//if queue was empty set timer
	if(j == 0){
			timerReset(sus, 14000000, 2000000);
	}
		
}


void timerReset(int timer [], int bottom, int range){
	        timer[0] = (rand() % range) + bottom + (*shm).clock[0];
                timer[1] = (*shm).clock[1];
                timeConvert(timer);
}


void printState(){
	fprintf(action, "Proc: ");
	int i;
        for(i = 0; i < prMax; i++){
                 fprintf(action, "%i ", (*shm).proc[i].pid );
        }
	fprintf(action, " \n");
	fprintf(action, "Blck: ");
	for(i = 0; i < prMax; i++){
                 fprintf(action, "%i ", blocked[i]);
        }
        fprintf(action, " \n");

	int j;
	for(i = 0; i <8; i++){
		for(j = i*32; j <32*(i+1); j++){	
                	fprintf(action, "%c", (*shm).pageTable[j].occupy);
		}
		fprintf(action,"\n" );
		for(j= i*32; j <32*(i+1); j++){
                        fprintf(action, "%c", (*shm).pageTable[j].reference);
                }
                fprintf(action,"\n" );
		fprintf(action,"\n" );
        }
}


void spawn(){

	int temp;

        //check if there is room for proc
	int newProc = 0;
	int i;
        for(i = 0; i < prMax; i++){
                if((*shm).proc[i].pid  == 0){
                        temp = fork();
                        newProc = 1;
                        break;
                }
	}

	// if there is a new process
	if(newProc == 1){
        	if(temp  == -1){
                	perror("oss: Error: Failed to fork");
                        kill(getpid(), SIGINT);
                }

                if(temp == 0){
                	execl("./user", NULL);
                        perror("oss: Error: exec failed for user process child");
                        kill(getpid(), SIGINT);;
                }
		
		prCount++;
		prTot++;

                (*shm).proc[i].pid  = temp;
                fprintf(action, "OSS: Spawning new process %i at %i:%09i \n", temp, (*shm).clock[1], (*shm).clock[0]);
                fflush(action);
                line++;

        }else{
                fprintf(action, "OSS: Process limit currently full unable to spawn more processes. \n");
                fflush(action);
                line++;
                }
}

int findPid(int pid){
        int i;
        for(i = 0; i <prMax; i++){
                if((*shm).proc[i].pid  == pid){ 
                       return i;
                }
        }    
	kill(getpid(),SIGINT);
}



void terminator(){

	//kill
	int i;
        for(i = 0; i < prMax; i++){
                if((*shm).proc[i].pid  != 0){
                        kill((*shm).proc[i].pid , SIGINT);
                }
        }

	//stats
	fprintf(action,"Number of memory accesses per sim second: %i \n", memAcc/(*shm).clock[1]);
	double a = ((double)pfault), b = ((double)memAcc);
	double y = a/b;
	fprintf(action,"Page faults per memory access: %f \n", y);
	fprintf(action,"Numher of Seg faults: %i \n", segs);
	double avgTime = (a*15000000 + ((b-a)*10))/b;
	fprintf(action,"Average time for memory access: %f NS\n", avgTime);
	fprintf(action,"%i bytes accessed in %i:%09i for %i process \n", memAcc, (*shm).clock[1], (*shm).clock[0], prTot);


	//wait and clear
	while(waitpid(-1, NULL, 0) != -1);
        shmctl(shmid, IPC_RMID, NULL);
        msgctl(msid, IPC_RMID, NULL);
}


void sigHandler(int signo){
        if (signo == SIGINT){
                terminator();
                exit(0);
        }
        if (signo == SIGSEGV){
                fprintf(stdout, "\nProcess Seg Fault. \n");
                terminator();
                exit(0);
        }
        if (signo == SIGALRM){
                fprintf(stdout, "\nProcess Time out. \n");
                terminator();
                exit(0);
        }

}


void timeConvert(int clock[]){
        clock[1] += clock[0]/1000000000;
        clock[0] = clock[0]%1000000000;
}


static int setperiodic(double sec) {
   timer_t timerid;
   struct itimerspec value;
   if (timer_create(CLOCK_REALTIME, NULL, &timerid) == -1)
      return -1;
   value.it_interval.tv_sec = (long)sec;
   value.it_interval.tv_nsec = (sec - value.it_interval.tv_sec)*BILLION;
   if (value.it_interval.tv_nsec >= BILLION) {
      value.it_interval.tv_sec++;
      value.it_interval.tv_nsec -= BILLION;
   }
   value.it_value = value.it_interval;
   return timer_settime(timerid, 0, &value, NULL);
}










































