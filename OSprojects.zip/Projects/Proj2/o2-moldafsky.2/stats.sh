#!/bin/bash
		
let count=0
let checktot=0
let texttot=0
let sleepavg=0

for f in *.log
do	
	((count++))
	let textcount=0
	let checkcount=0
	let sleepcount=0
	let sleeptime=0
	let sleeptot=0
	echo $f
	exec < $f
	while read LINE
	do
		((textcount++))
		if [[ $LINE = *'Sleep'* ]]
	        then
			((sleepcount++))
			sleeptime=$(echo $LINE | sed -n 's/^.*Sleep //p')
			let sleeptot=sleeptot+sleeptime 
        	fi
		if [[ $LINE = *'Check'* ]]
                then
			((checkcount++))
                fi
	done

	echo "number of text messages written " $textcount
	echo "number of time attempting to enter critical section " $checkcount
	echo "total time slept " $sleeptot
	echo " "
	
	let checktot=checktot+checkcount
	let texttot=texttot+textcount	
	let sleepavg=sleepavg+sleeptot
done

let texttot=texttot/count
let checktot=checktot/count

echo "Average number of text messages written: "$texttot
echo "Average number of crit section attempts: "$checktot
echo "Average amount of time slept: "$sleepavg 
