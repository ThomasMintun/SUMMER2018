#include<stdio.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<unistd.h>
#include<string.h>
#include<sys/wait.h>
#include<signal.h> //for signal handling
#include<stdlib.h> //exit function
#include<sys/types.h> //kill function
#include<time.h> // for setperiodic
#define BILLION 1000000000L //for setperiodic



//global variable
int buffshmid; //holds id of shared memory buffer
key_t buffkey; //shm key fo buffer
int turnshmid; //holds id turn
key_t turnkey; //shm key of turn
int flagshmid; //holds id of flags
key_t flagkey; //shm key to flags
int bflagshmid;
key_t bflagkey;
pid_t childpid[64]; //holds id of children
int n; // number of comsumer process to be spawned. from command line.

enum state{ idle, want_in, in_cs };

//signal handling function
void sigHandler(int signo);

//countdown taken from book
static int setperiodic(double sec);

int main(int argc, char **argv){

	char (*buffer)[5]; //pointer to 5  buffers
	int pr_count = 0;
	int pr_limit = 20;
	char (*bflag);		

	//catch SIGINT and SIGALRM
	if (signal(SIGINT, sigHandler) == SIG_ERR)
        	perror("master: can't catch SIGINT");
	if (signal(SIGALRM, sigHandler) == SIG_ERR)
                perror("master: can't catch SIGALRM");

	//set timer
	if (setperiodic(100.0) == -1) {
                perror("Failed to setup periodic interrupt");
                return 1;}

	//option handler
	int opt;
        while((opt = getopt (argc, argv, "h")) != -1)
                switch (opt){
                        case 'h':
                                printf("Program spawns producer child and takes integer\n");
                                printf("argument 0-20 to spawn specified number of consumer children.\n");
				printf("No argument defaults consumer children to 10. \n");
                                printf("This program reads from inputfile and writes to output file. \n");
                                printf("It also creates log file for each child process.\n");
                                return 0;
                                break;}

	//if there are no arguments
	if(argc <= 1){
		n = 10;}
	else{	
		if(atoi(argv[1]) < 0 || atoi(argv[1]) > 19){
			perror("master: incorrect argument entry, enter int above 0 and no greater than 19.");
			return 1;}
		else{
			n = atoi(argv[1])+1;}}


	//creates shared memory
	buffkey = 2814;
	if((buffshmid = shmget(buffkey, sizeof( 5*128*8), IPC_CREAT | 0666)) == -1){
		perror("master: shmget failed");
		return 1;}
	flagkey = 2815;
	if((flagshmid = shmget(flagkey, sizeof(n*8), IPC_CREAT | 0666)) == -1){
               perror("producer: flag shmget failed");
               return 1;}
	turnkey = 2816;
        if((turnshmid = shmget(turnkey, sizeof(8), IPC_CREAT | 0666)) == -1){
                perror("producer: shmget failed");
                return 1;}
	bflagkey = 2817;
        if((bflagshmid = shmget(bflagkey, sizeof(50), IPC_CREAT | 0666)) == -1){
                perror("producer: shmget failed");
                return 1;}

	

	//attach memory to buffer pointer
	bflag = shmat(bflagshmid, NULL, 0);
	
	//prepare vars to be sent as parameter with execl
	int k;	
	for(k = 0; k < 5; k++)
		bflag[k] = '0';
	
	//forks child processes
	int i;
	for(i = 0; i < n; i++){ 

		//check process limit		
		if(pr_count == pr_limit){
               		wait(NULL);
               		pr_count--;}
	
		childpid[i] = fork();
		if(childpid[i] == -1){	
			perror("master: Error: Failed to fork");
                	return 1;}
		
		//prepare vars to be sent as parameter with execl
		char str[8];
		char str1[8];
		sprintf(str,"%i", i);
         	sprintf(str1,"%i", n);
	
		//execs producer and consumers
		if(childpid[i] == 0){
			if(i == 0){
				execl("./producer", str, str1, (char*) NULL);
				perror("master: Error: exec failed for producer child");
				return 1;}
			else{
				execl("./consumer", str, str1, (char*) NULL);
                                perror("master: Error: exec failed for consumer child");
				return 1;}}
		

		//check to see if any process have finished
		pr_count++;
	        while(waitpid(-1, NULL, WNOHANG) != 0)
          	     pr_count--;}

	//wait for all remain child processes to end
	while(waitpid(-1, NULL, 0) != -1);
        
	//clear memory
	printf("program finished. \n");
	shmctl(buffshmid, IPC_RMID, NULL);
	shmctl(flagshmid, IPC_RMID, NULL);
	shmctl(turnshmid, IPC_RMID, NULL);
	shmctl(bflagshmid, IPC_RMID, NULL);
	return 0;
}


void sigHandler(int signo){
  	if (signo == SIGINT || signo == SIGALRM){
    		fprintf(stderr, "\nMaster SIGINT received \n");
		int i;
		//kill children
	        for(i = 0; i < n+1; i++)
			kill(childpid[i], SIGINT);
		while(waitpid(-1, NULL, 0) != -1);
		shmctl(buffshmid, IPC_RMID, NULL);
		shmctl(flagshmid, IPC_RMID, NULL);
	        shmctl(turnshmid, IPC_RMID, NULL);
		shmctl(bflagshmid, IPC_RMID, NULL);
		exit(0);}
}


static int setperiodic(double sec) {
   timer_t timerid;
   struct itimerspec value;
   if (timer_create(CLOCK_REALTIME, NULL, &timerid) == -1)
      return -1;
   value.it_interval.tv_sec = (long)sec;
   value.it_interval.tv_nsec = (sec - value.it_interval.tv_sec)*BILLION;
   if (value.it_interval.tv_nsec >= BILLION) {
      value.it_interval.tv_sec++;
      value.it_interval.tv_nsec -= BILLION;
   }
   value.it_value = value.it_interval;
   return timer_settime(timerid, 0, &value, NULL);
}

