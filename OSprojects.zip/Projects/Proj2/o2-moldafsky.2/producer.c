#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h> 
#include <sys/shm.h> 
#include <signal.h> //signal handling
#include <stdlib.h> //exit function
#include <time.h>

//global variables
key_t buffkey = 2814; // key of shm buffer
int buffshmid; //id of shm buffer
int turnshmid; //holds id turn
key_t turnkey = 2816; //shm key of turn
int flagshmid; //holds id of flags
key_t flagkey = 2815; //shm key to flags
int bflagshmid;// holds id for buff flags
key_t bflagkey = 2817; // holds key for buff flags
int j; //used in critical sections
FILE *log; //file to write actions in

//enums used in crit sectiosn
enum state{ idle, want_in, in_cs };

//signal handling function
void sigHandler(int signo);

void precrit(int i, int n, enum state (*flag), int *turn);

void postcrit(int i, int n, enum state (*flag), int *turn);

//write system time to log
void getTime();

int main (int argc, char *argv[]){

	//catch SIGINT 
	if (signal(SIGINT, sigHandler) == SIG_ERR)
                perror("master: can't catch SIGINT");		

	int n = atoi(argv[1]);
	int i = atoi(argv[0]);
	char (*buffer)[128];
	enum state *flag;
	int *turn;
	char (*bflag);
	time_t t;

	// seed ranom number generator
	srand((unsigned) time(&t));
	
	//open text files
	FILE *f = fopen("inputfile", "r");
	log = fopen("prod.log", "a");

	//write to log
	getTime();
	fprintf(log, "Started\n");
	
	//creates shared memory
	if(( buffshmid = shmget(buffkey, sizeof(5*128*8), 0666)) == -1){
               perror("producer: shmget failed");
               return 1;}
	if((flagshmid = shmget(flagkey, sizeof(n*8), 0666)) == -1){
               perror("producer: flag shmget failed");
               return 1;}
        if((turnshmid = shmget(turnkey, sizeof(int), 0666)) == -1){
                perror("producer: shmget failed");
                return 1;}
	if((bflagshmid = shmget(bflagkey, sizeof(50), 0666)) == -1){
                perror("producer: shmget failed");
                return 1;}

	
	//attach memory
       	buffer  = shmat(buffshmid, NULL, 0);
	flag = shmat(flagshmid, NULL, 0); 
	turn = shmat(turnshmid, NULL, 0);  
	bflag = shmat(bflagshmid, NULL, 0);

	//critical section work
	do{
	precrit(i, n, flag, turn);
	char ch;
	int k = 0;
	int m;
	getTime();
        fprintf(log, "Check\n");
	for(m = 0; m < 5; m++){
        	if(bflag[m] == '0'){
			bflag[m] = '1';
			while((ch = getc(f)) != '\n' && !feof(f)){
				buffer[m][k] = ch;
				k++;}
			getTime();
                        fprintf(log, "Write %i %s\n", m, buffer[m]);
			break;}}
	postcrit(i, n, flag, turn);
	int s =(rand() %2) + 1;
	getTime();
        fprintf(log, "Sleep %i\n", s);
	sleep(s);
	}while(!feof(f));
	
	int m;
	int cont =1;
	while(cont == 1){
		cont = 0;
		for(m = 0; m < 5; m++){
			if (bflag[m] == '0')
                        	bflag[m] = '2';
			if (bflag[m] != '2')
				cont =1;
		}
	}


	getTime();
        fprintf(log, "Terminated Normal\n");
	return 0;
}

void sigHandler(int signo){
        if (signo == SIGINT || signo == SIGALRM){
                getTime();
		fprintf(stderr, "Producer %i SIGINT recieved.\n", getpid());
        	fprintf(log, "Terminated killed\n");
                exit(0);}
}

void precrit(int i, int n, enum state (*flag), int *turn) {

	do {
 		flag[i] = want_in; // Raise my flag
 		j = *turn; // Set local variable
 		// wait until its my turn
   		while ( j != i )
			j = ( flag[j] != idle ) ? *turn : ( j + 1 ) % n;

     		// Declare intention to enter critical section
      		flag[i] = in_cs;

       		// Check that no one else is in critical section
        	for ( j = 0; j < n; j++ )
        		if ( ( j != i ) && ( flag[j] == in_cs ) )
          			break;
           		} while ( ( j < n ) || ( *turn != i && flag[*turn] != idle ) ); 
	
	// Assign turn to self and enter critical section
	*turn = i;
}

void postcrit(int i, int n, enum state (*flag), int *turn){
	// Exit section
	j = (*turn + 1) % n;
 	while (flag[j] == idle)
 		j = (j + 1) % n; 
	
	// Assign turn to next waiting process; change own flag to idle
	*turn = j; flag[i] = idle; 
}

void getTime()
{	
	char buf[150];
  	time_t rawtime;
  	struct tm * timeinfo;

  	time ( &rawtime );
  	timeinfo = localtime ( &rawtime );
  	strftime(buf, 150, "%I:%M:%S: ", timeinfo);
	fprintf(log, "%s", buf);
}











