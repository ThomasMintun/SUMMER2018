#include <stdio.h>
#include <stdlib.h> //exit function
#include <sys/ipc.h> //shared memory
#include <sys/shm.h> //shared memory
#include <sys/msg.h> //for message passing
#include <string.h> //strcpy
#include <unistd.h> //for exec
#include <sys/types.h> // for wait
#include <sys/wait.h> // for wait and kill
#include <signal.h> //for signal handling
#include<time.h> // for setperiodic
#define BILLION 1000000000L //for setperiodic


//global variables
key_t mspkey; //key for parent box
key_t msckey; // key for child box
key_t shmkey; // key for shared memory
int mspid; // id of message queue for parent box
int mscid; // id of message queue for child box
int shmid; // id of shared memory
int childpid; //id of child
FILE *output; //file to write actions in
int pids[30];


//message queue struct
struct mesg_buffer {
    	long mesg_type;
    	int mesg_curtime;
    	int mesg_strtime[2];
	int mesg_pid;
} message;

//signal handler
void sigHandler(int signo);

//convert nanoseconds to seconds
void timeConvert(int clock[]);

//countdown taken from book
static int setperiodic(double sec);


int main(int argc, char *argv[]){

	//variables
	mspkey = ftok("oss", 65); // generate key for crit sec
	msckey = ftok("oss", 66); //generate key for child box
	shmkey = ftok("oss", 67); // key for shared memory
	int pr_count = 0; //number of current children.
	int pr_limit = 5; //max nbumber of slaves
	double runtime = 20; // time until process dies
	char fname[128]; // file name to exec
	int (*clock); // artificial process clock
	int totalcnt = 0;

	//signal handler
	if (signal(SIGINT, sigHandler) == SIG_ERR)
        	perror("master: can't catch SIGINT");
	if (signal(SIGALRM, sigHandler) == SIG_ERR)
                perror("master: can't catch SIGALRM");


	//option handler
	int opt;
        while((opt = getopt (argc, argv, "hs:l:t:")) != -1)
                switch (opt){
                        case 'h':
                                printf("Program spawns run children and uses some shared memory.\n");
                                printf("-s option takes integer argument which limits how many children are alive at once.  default 5\n");
                                printf("-l option takes string argument to name what file program will output to. THIS IS MANDATORY\n");
                                printf("-t option takes double argument for the processes real world time limit in secounds. Default 20 seconds \n");
                                return 0;
                                break;
			case 's':
				pr_limit = atoi(optarg);
				break;
			case 't':
				runtime = atof(optarg);
				break;
			case 'l':
				strcpy(fname, optarg);
				break;		
		}

	 //set timer
	 if (setperiodic(runtime) == -1) {
	 	perror("Failed to setup periodic interrupt");
	 	return 1;}

	if (fname[0] == '\0'){
		perror("must use -l option with string argument");
		return 0;
	}

	//open file for output
	output = fopen(fname, "a");	

	//create shared memory
	if((shmid = shmget(shmkey, 3*sizeof(int), IPC_CREAT | 0666)) == -1){
                perror("oss: Error: shmget failed");
                return 1;}

	// attach memory to clock and set to zerp
	clock =  shmat(shmid, NULL, 0);
	clock[0] = 0; //nanoseconds
	clock[1] = 0; //seconds

	//initialize child message queue
	if ((mspid = msgget(mspkey, IPC_CREAT | 0666)) == -1){
    		perror("oss: Error: msgget");
    		return 1;
   	}

	//initialize parent message queue
	if ((mscid = msgget(msckey, IPC_CREAT | 0666)) == -1){
                perror("oss: Error: msgget");
                return 1;
        }
		
	//load up message struct
	message.mesg_type = 1;
	
	//send message initializing message to child box
	if(msgsnd(mscid, &message, sizeof(message), 0) == -1){
		perror("oss: Error: msgsnd");
	}

	memset(pids, 0 , sizeof(pids));

	int i;
	// main loop
	while (clock[1] < 2){
		
		//spawn and track children
		while(pr_count < pr_limit){

			for(i = 0; i < sizeof(pids)/sizeof(int); i++){
                        	if(pids[i] == 0){
                                        pids[i] = fork();
                                        break;
                           	}    
			}
                       
		
                	if(pids[i] == -1){
                      		perror("oss: Error: Failed to fork");
                       		return 1;
                	}	

			if(pids[i] == 0){
                		execl("./run", NULL);
                		perror("oss: Error: exec failed for producer child");
                		return 1;
			}

			fprintf(output, "Creating new child pid %i at my time %i.%09i\n", pids[i], clock[1], clock[0]);
                        fflush(output);

			//track process count
			pr_count++;
			totalcnt++;
			if(totalcnt >= 100)
				break;
		}	
		
		if(totalcnt >= 100)
                 	break;
	
		//Critical section
                //recieve message from parent box
                msgrcv(mspid, &message, sizeof(message), 1, 0);
		if (clock[1] >= 2)
			break;
		
		pr_count--;
		
		// arithmetic for output
		int elapsed[2];
		elapsed[0] = ((clock[1] * 1000000000) + clock[0]) - ((message.mesg_strtime[1] * 1000000000) + message.mesg_strtime[0]);
		if (elapsed[0] >= 1000000000)
			timeConvert(elapsed);

  		//output clock time
		fprintf(output, "Child pid %i is terminating at my time %i.%09i because it reached 0.%09i which lived for time %i.%09i\n", message.mesg_pid, clock[1], clock[0], message.mesg_curtime, elapsed[1], elapsed[0]);
		fflush(output);
		
		for(i = 0; i < sizeof(pids)/sizeof(int); i++){
			if(pids[i] == message.mesg_pid){
				pids[i] = 0;
			}
		}

		memset(elapsed, 0 , sizeof(elapsed));

		//time to do this process
		clock[0] += 100;
		timeConvert(clock);

		//load up message struct
		message.mesg_type = 1;

                //send message to child box
                if(msgsnd(mscid, &message, sizeof(message), 0) == -1){
                        perror("oss: Error: msgsnd");
                }
        }

	fprintf(stderr, "SYSTEM SHUTDOWN\n");
	
	for(i = 0; i < sizeof(pids)/sizeof(int); i++){
		if (pids[i] != 0)
        		kill(pids[i], SIGINT);
	}

	//wait for all remaining child processes to end
	while(waitpid(-1, NULL, 0) != -1);

	//remove message buffer
        shmctl(shmid, IPC_RMID, NULL);
	msgctl(mspid, IPC_RMID, NULL);
        msgctl(mscid, IPC_RMID, NULL);

	return 0;
}



void sigHandler(int signo){
        if (signo == SIGINT || signo == SIGALRM){
                fprintf(stderr, "oss %i SIGINT received \n", getpid());
		int i;
		for(i = 0; i < sizeof(pids)/sizeof(int); i++){
           	     kill(pids[i], SIGINT);
  	        }

 		while(waitpid(-1, NULL, 0) != -1);
		shmctl(shmid, IPC_RMID, NULL);
		msgctl(mspid, IPC_RMID, NULL);
		msgctl(mscid, IPC_RMID, NULL);

		exit(0);
	}
}

static int setperiodic(double sec) {
   timer_t timerid;
   struct itimerspec value;
   if (timer_create(CLOCK_REALTIME, NULL, &timerid) == -1)
      return -1;
   value.it_interval.tv_sec = (long)sec;
   value.it_interval.tv_nsec = (sec - value.it_interval.tv_sec)*BILLION;
   if (value.it_interval.tv_nsec >= BILLION) {
      value.it_interval.tv_sec++;
      value.it_interval.tv_nsec -= BILLION;
   }
   value.it_value = value.it_interval;
   return timer_settime(timerid, 0, &value, NULL);
}

void timeConvert(int clock[]){
        clock[1] += clock[0]/1000000000;
        clock[0] = clock[0]%1000000000;
}

