#include <stdio.h>
#include <sys/ipc.h> //shared memory
#include <sys/msg.h> //message passing
#include <sys/shm.h> //shared memory
#include <string.h> //strcpy
#include <signal.h> //for signal handling
#include <stdlib.h> //exit function
#include <time.h>

//struct for message
struct mesg_buffer {
    	long mesg_type;
    	int mesg_curtime;
	int mesg_strtime[2];
	int mesg_pid;
} message;
 
//signal handling function
void sigHandler(int signo);

void timeConvert(int clock[]);

int main(int argc, char *argv[]){
	
	//signal handler
	if (signal(SIGINT, sigHandler) == SIG_ERR)
                perror("master: can't catch SIGINT");
	 if (signal(SIGALRM, sigHandler) == SIG_ERR)
                perror("master: can't catch SIGALRM");
	 if (signal(SIGQUIT, sigHandler) == SIG_ERR)
                perror("master: can't catch SIGALRM");


	//variables
 	key_t mspkey = ftok("oss", 65); //key for parent box
	key_t msckey = ftok("oss", 66); // key for child box
	key_t shmkey = ftok("oss", 67); // key for shared memory
	int mspid; // id of message queue for parent box
	int mscid; // id of message queue for child box
	int shmid; // id of shared memory
	int (*clock); //sim sys clock from shm
	int runtime; //time the process will run in sim sys
	int curtime = 0; // current running time of process
	int strtime[2]; // sim sys time process started
	int work = 300000; //work process does in one run
	time_t t;

	//seed ranom number generator
	srand((unsigned) time(&t) + getpid());

	//access message queue
	mspid = msgget(mspkey, 0666);
	mscid = msgget(msckey, 0666);

	//get shared memory
	if((shmid = shmget(shmkey, (3*sizeof(int)), 0666)) == -1){
        	perror("run: Error: shmget failed");
                return 1;}

	//attach memory to clock
	clock = shmat(shmid, NULL, 0);
	strtime[0] = clock[0];
	strtime[1] = clock[1]; 

	//get program run time
	runtime =(rand() %100000000) + 1; 
	
	//critical section
	while(curtime < runtime){

        	//recieve message from child box enter crit
        	msgrcv(mscid, &message, sizeof(message), 1, 0);
	

		//load up message struct
       		message.mesg_type = 1;

		//check to see if run exceeds allowed runtime
		if((curtime + work) > runtime ){
			work = runtime - curtime;
		}

		//increment clocks
		clock[0] += work;
		curtime += work;
		
		//convert nanoseconds to secs if need be
		if(clock[0] >= 1000000000)
			timeConvert(clock);
 	
		//check system time and shutdown
		if(clock[1] >= 2)
			//send message to parent box
                        if(msgsnd(mspid, &message, sizeof(message), 0) == -1){
                		perror("run: Error: msgsnd");
               		}		

		//send message to child box exit crit
		if(curtime < runtime){
			if(msgsnd(mscid, &message, sizeof(message), 0) == -1){
        			perror("oss: Error: msgsnd");
        		}
		}
	}
	
	//load up message struct
	message.mesg_type = 1; 
	message.mesg_curtime = curtime; 
	message.mesg_strtime[0] = strtime[0];
	message.mesg_strtime[1] = strtime[1];
  	message.mesg_pid = getpid();

	
	//send message to parent box
	if(msgsnd(mspid, &message, sizeof(message), 0) == -1){
        	perror("run: Error: msgsnd");
        }

    
	return 0;
}



void sigHandler(int signo){
	if (signo == SIGINT || signo == SIGALRM || signo == SIGQUIT){
		fprintf(stderr, "run %i SIGINT recieved.\n", getpid());
		exit(0);
	}
}

void timeConvert(int clock[]){
	clock[1] += clock[0]/1000000000;
	clock[0] = clock[0]%1000000000;
}

