#include <stdio.h> //input output
#include <stdlib.h> //exit function>
#include <sys/ipc.h> //shared memory
#include <sys/msg.h> //message passing
#include <sys/shm.h> //shared memory
#include <signal.h> //for signal handling
#include <time.h> // for setperiodic

//structs
struct pct{
        int timeAsleep[2]; //total cpu time used
        int timeAlive[2]; //total time in system
        int timeBurst[2]; //time used in last burst
	int timeCreated[2]; // time of creation
	int timeWait[2]; // time waited
	int timeSlept[2];
	int blockedTo[2]; //time blocked until
	int blocked; //blocked or not
        int pid; //simulated pid
        int priority; //process priority
}table;

struct mesg_buffer {
        long mesg_type;
        int slice;
	int i;
	int first;
} message;

//signal handling function
void sigHandler(int signo);

//convert NS
void timeConvert(int clock[]);

int main(int argc, char *argv[]){

	//variables
	key_t mskey = ftok("oss", 51); // key for message
        key_t shmkey = ftok("oss", 52); // key for shared memory clock
	key_t prockey = ftok("oss", 53); // key for shared pct
	int shmid; // id of shared memory
	int procid; //pct id
	int msid; //id of message queue	
	int (*clock); // shared clock
	time_t t; //time seed
	struct pct (*procBlock);//process table
	int i;
	int birth[2];// time made
	int runs = 0;
	int finishTime[2];

	//seed random generator
	srand((unsigned) time(&t) + getpid());

	//signal handler
	if (signal(SIGINT, sigHandler) == SIG_ERR)
                perror("master: can't catch SIGINT");
	if (signal(SIGALRM, sigHandler) == SIG_ERR)
                perror("master: can't catch SIGALRM");	

	//access message queue
	msid = msgget(mskey, 0666);

	//get shared memory
	if((shmid = shmget(shmkey, (2*sizeof(int)), 0666)) == -1){
                perror("user: Error: shmget failed");
                return 1;}
	if((procid = shmget(prockey, (18*sizeof(table)), 0666)) == -1){
                perror("user: Error: shmget failed");
                return 1;}
	
	// attach memory
	procBlock  = shmat(procid, NULL, 0);
        clock  = shmat(shmid, NULL, 0);

	//creation time
	birth[0] = clock[0];
	birth[1] = clock[1];

	// find process block
	for(i = 0; i < 18; i++){
                if(procBlock[i].pid == getpid()){
			//fprintf(stderr, "%i\n", i);
			//fflush(stderr);
			break;
		}
        }

	while(1){

		//recieve message
		msgrcv(msid, &message, sizeof(message), getpid(), 0);
		
		if(runs == 0){
			if(clock[1] >= 1){
               		clock[1] -= 1;
          		clock[0] += 1000000000;
        		}
			procBlock[i].timeSlept[0] = clock[0]- procBlock[i].timeCreated[0];
			procBlock[i].timeSlept[1] = clock[1]- procBlock[i].timeCreated[1];
			timeConvert(clock);
		        timeConvert(procBlock[i].timeSlept);
		} else {
			if(clock[1] >= 1){
                        clock[1] -= 1;
                        clock[0] += 1000000000;
                        }
                        procBlock[i].timeSlept[0] += clock[0]- finishTime[0];
                        procBlock[i].timeSlept[1] += clock[1]- finishTime[1];
                        timeConvert(clock);
                        timeConvert(procBlock[i].timeSlept);
		}		

		runs++;

		procBlock[i].timeBurst[0] = message.slice;

		//terminate?
		if((rand() % 100) >= 75){
			procBlock[i].timeBurst[0] = (rand() % message.slice)+1;
			procBlock[i].priority = -1;
			break;
		}

		//blocked?
		if(rand() % 100 >= 92){
			procBlock[i].timeBurst[0] = (rand() % message.slice)+1;
                        procBlock[i].blocked = 1;
			procBlock[i].blockedTo[0] = clock[0] + (rand() % 1000) + 1;
			timeConvert(procBlock[i].blockedTo);
			procBlock[i].blockedTo[1] = (rand() % 5) + 1 + clock[1];
		}
		
		finishTime[0]=clock[0];
		finishTime[1]=clock[1];

		//send message if not terminated
		message.mesg_type = 1;
		message.i = i;
		if(msgsnd(msid, &message, sizeof(message), 0) == -1){
                	perror("user: Error: msgsnd");
 	        }
	}

	//time alive
	if(clock[1] >= 1){
		clock[1] -= 1;
		clock[0] += 1000000000;	
	}
	procBlock[i].timeAlive[0] = clock[0]+procBlock[i].timeBurst[0] - procBlock[i].timeCreated[0];
	procBlock[i].timeAlive[1] = clock[1] - procBlock[i].timeCreated[1];
	timeConvert(clock);
	timeConvert(procBlock[i].timeAlive);	

	double usedAverageD = (double)procBlock[i].timeSlept[1];
        usedAverageD = usedAverageD/runs;
        procBlock[i].timeWait[0] = procBlock[i].timeSlept[0]/runs;
        procBlock[i].timeWait[0] += (usedAverageD - (int)usedAverageD) * 1000000000; 
	procBlock[i].timeWait[1] = usedAverageD;

	//send message if terminated
	message.i = i;
	message.mesg_type = 1;
        if(msgsnd(msid, &message, sizeof(message), 0) == -1){
                perror("user: Error: msgsnd");
	}

	//termination
	
	return 0;
}

void timeConvert(int clock[]){
        clock[1] += clock[0]/1000000000;
        clock[0] = clock[0]%1000000000;
}

void sigHandler(int signo){
        if (signo == SIGINT || signo == SIGALRM || signo == SIGQUIT){
                fprintf(stderr, "run %i SIGINT recieved.\n", getpid());
                exit(0);
        }
}



