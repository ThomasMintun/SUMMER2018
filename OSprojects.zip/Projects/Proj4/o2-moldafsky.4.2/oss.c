#include <stdio.h> //input output
#include <stdlib.h> //for exit
#include <sys/ipc.h> // shared memory
#include <sys/shm.h> // shared memory
#include <unistd.h> // execl
#include <signal.h> //signal handling
#include <sys/types.h> // for wait
#include <sys/wait.h> // for wait and kill
#include <time.h> // for setperiodic
#include <string.h> // for memset
#include <math.h> //for pow
#define BILLION 1000000000L //for setperiodic


struct pct{
        int timeAsleep[2]; //total cpu time used
        int timeAlive[2]; //total time in system
        int timeBurst[2]; //time used in last burst
	int timeCreated[2]; // time of creation
        int timeWait[2]; // time waited
        int timeSlept[2]; // time slept
        int blockedTo[2]; //time blocked until
        int blocked; //blocked or not
        int pid; //simulated pid
        int priority; //process priority
}table;


//global variables
key_t shmkey; // key for shared memory clock
int shmid; // id of shared memory clock
key_t prockey; // key for shared memory
int procid; // id of shared memory
key_t mskey; //message key
int msid; //message id
const int tabSize = 18; //amount of processes
int averageLife[2]; //average time used by process
int prCount = 0; // total amount of processes created
int pids[18]; // array of pids
struct pct (*procBlock); // process block array
int averageSleep[2]; //time slept
int averageWait[2]; //time spent waiting
int idle[2]; // time with no programs
FILE *output, *queues; //files for output

struct mesg_buffer {
       long mesg_type;
	int slice;
	int i;
	int first;
} message;

//find average of stats
void Divide(int usedAverage[]);

//function to terminate and print
void terminator();

//signal handler
void sigHandler(int signo);

//convert nanoseconds to seconds
void timeConvert(int clock[]);

//countdown taken from book
static int setperiodic(double sec);

//queueing functions
void enqueue(int queue[], int pid);
void dequeue(int queue[]);
int checkQueue(int queue[]);

int main(int argc, char *argv[]){

	//variables
	shmkey = ftok("oss", 52); // key for shared memory
	prockey = ftok("oss", 53); // key for shared memory
	mskey = ftok("oss", 51); // generate key for crit sec
	const int maxTimeBetweenNewProcsNS = 1000000000;
	const int maxTimeBetweenNewProcsSecs = 2;
	int (*clock); // simulated clock
	int untilNew[2]; //countdown timer until new process
	time_t t; //for time seeding
	int queue[4][tabSize]; //priority scheduling queues
	int blockQueue[tabSize];
	int q = 100000000; //time quantum
	int line = 0; //count output lines

	int opt;
        while((opt = getopt (argc, argv, "h")) != -1)
                switch (opt){
                        case 'h':
                                printf("Program spawns user children, uses some shared memory, and message queues.\n");
                                printf("Program will create to output logs output.log and queue.log\n");
                                printf("Takes no arguments.\n");
                                return 0;
                                break;}

	//seed random generator
	srand((unsigned) time(&t) + getpid());

	//signal handler
	if (signal(SIGINT, sigHandler) == SIG_ERR)
	        perror("oss: can't catch SIGINT");
	if (signal(SIGALRM, sigHandler) == SIG_ERR)
                perror("master: can't catch SIGALRM");	

	//set timer
	if (setperiodic(3) == -1) {
                perror("Failed to setup termination timer");
                return 1;
	}

	//open files
	output = fopen("action.log", "a");
	queues = fopen("queue.log", "a");

	//create shared memory
	if((shmid = shmget(shmkey, (2*sizeof(int)), IPC_CREAT | 0666)) == -1){
        	perror("oss: Error: shmget failed");
                return 1;
	}
	if((procid = shmget(prockey, (18*sizeof(table)), IPC_CREAT | 0666)) == -1){
                perror("oss: Error: shmget failed");
                return 1;
        }
	
	//initialize message queue
	if ((msid = msgget(mskey, IPC_CREAT | 0666)) == -1){
                perror("oss: Error: msgget");
                return 1;
        }


	//attach shared memory to clock and pct
	procBlock  = shmat(procid, NULL, 0);
	clock  = shmat(shmid, NULL, 0);

	//set clock
	clock[0] = 0; //nanoseconds
        clock[1] = 0; //seconds
	untilNew[0] = (rand() % maxTimeBetweenNewProcsNS) + 1;
        untilNew[1] = (rand() % maxTimeBetweenNewProcsSecs);

	//prepare pids array and queues
	memset(queue, 0, sizeof(queue));
	memset(pids, 0, sizeof(pids));
	memset(idle, 0, sizeof(idle));
	memset(blockQueue, 0, sizeof(blockQueue));
	memset(averageLife, 0, sizeof(averageLife));
	int i;

	//send message to self
	message.mesg_type = 1;
	message.first = 1;
	if(msgsnd(msid, &message, sizeof(message), 0) == -1){
                perror("oss: Error: msgsnd");
        }

	//main loop
	//forks children and tracks them
	while(1){

		//check for active processes
		int empty = 0;
                for(i = 0; i < tabSize; i++){
                        if(procBlock[i].pid != 0 && procBlock[i].blocked == 0){
	                        empty = 1;
				break;
			}
		}

		//go to clock time if no processes
		if(empty == 0){
			if(prCount >= 100)
				break;
			if(untilNew[1] > 0){
				untilNew[1] -= 1;
				untilNew[0] += 1000000000;
			}
			idle[0] += (untilNew[0]- clock[0]);
			idle[1] += (untilNew[1]- clock[1]);
			timeConvert(untilNew);
			timeConvert(clock);
			timeConvert(idle);
                        clock[0] = untilNew[0];
                        clock[1] = untilNew[1];
                }

		//fork new child at timer
		if(((clock[1] == untilNew[1] && clock[0] >= untilNew[0]) || clock[1] > untilNew[1]) && prCount < 100 ){	

		
			if(line >= 1000){
				fclose(output);
			}
		
			//check if proc table is full
			int newProc = 0;                	
                	for(i = 0; i < sizeof(pids)/sizeof(int); i++){
                                if(pids[i] == 0){
					prCount++;
                			pids[i] = fork();
					newProc = 1;
					break;
				}
			}

			//in case of new process
			if(newProc == 1){
               			if(pids[i] == -1){
                       			perror("oss: Error: Failed to fork");
                       			kill(getpid(), SIGINT);
               			}

                		if(pids[i] == 0){
                        		execl("./user", NULL);
                	        	perror("oss: Error: exec failed for user process child");
        	                	return 1;
	        		}
			


				//allocate process block
				procBlock[i].timeCreated[0] = clock[0]; 
				procBlock[i].timeCreated[1] = clock[1];
				memset(procBlock[i].timeAlive, 0, 2*sizeof(int));
				memset(procBlock[i].timeBurst, 0, 2*sizeof(int));
				procBlock[i].pid = pids[i];
				procBlock[i].blocked = 0;

				//set priority and place in queue
				if((rand() % 50 + 1) >= 42){
					procBlock[i].priority = 0; //realtime
					enqueue(queue[0], pids[i]);
				}
				else{
					procBlock[i].priority = 1; //feedback
					enqueue(queue[1], pids[i]);
				}

				fprintf(output, "OSS: Generating process with PID %i", pids[i]);
				fprintf(output, " and putting it in queue %i", procBlock[i].priority);
				fprintf(output, " at time %i:%09i\n", clock[1], clock[0]);
				fflush(output);
				line++;
			}

			//reset timer
			untilNew[0] = (rand() % maxTimeBetweenNewProcsNS) + clock[0];
                        untilNew[1] = (rand() % maxTimeBetweenNewProcsSecs) + clock[1];
			timeConvert(untilNew);
                        fprintf(output, "OSS: Timer set. Attempt to spawn new process at:  %i:%09i \n", untilNew[1], untilNew[0]);
			fflush(output);
			line++;
		}
		

		//crit section
		//recieve message
		msgrcv(msid, &message, sizeof(message), 1, 0);
		
		//if process terminated
		if(procBlock[message.i].priority == -1){
			fprintf(output, "OSS: Receiving that process with PID %i", procBlock[message.i].pid); 
	                fprintf(output, " ran for %09i nanoseconds and terminated", procBlock[message.i].timeBurst[0]);
			fprintf(output, " not using its entire time quantum\n");
			fflush(output);
			line++;

			//add averages
			averageLife[0] += procBlock[message.i].timeAlive[0];
			averageLife[1] += procBlock[message.i].timeAlive[1];
			timeConvert(averageLife);
			averageSleep[0] += procBlock[message.i].timeSlept[0];
                        averageSleep[1] += procBlock[message.i].timeSlept[1];
                        timeConvert(averageSleep);
			averageWait[0] += procBlock[message.i].timeWait[0];
                        averageWait[1] += procBlock[message.i].timeWait[1];
                        timeConvert(averageWait);
			pids[message.i] = 0;		
			procBlock[message.i].pid = 0;	
		}	

		//if process was blocked
		if(procBlock[message.i].blocked == 1 && message.first != 1){
                        fprintf(output, "OSS: Receiving that process with PID %i", procBlock[message.i].pid);
                        fprintf(output, " ran for %09i nanoseconds and got blocked", procBlock[message.i].timeBurst[0]);
                        fprintf(output, " not using its entire time quantum\n");
			fflush(output);
			line++;
			enqueue(blockQueue, message.i+1);
			fprintf(output, "OSS: Placing process with  PID %i in blocked queue to be woken", procBlock[message.i].pid);
			fprintf(output, " up at %i:%09i\n", procBlock[message.i].blockedTo[1], procBlock[message.i].blockedTo[0]);
			fflush(output);
			line++;
		}	
		
		//place last running program in queue
		if(procBlock[message.i].priority != -1 && message.first != 1 && procBlock[message.i].blocked != 1){
			//lower priority
			fprintf(output, "OSS: Receiving that process with PID %i", procBlock[message.i].pid); 
                	fprintf(output, " ran for %09i nanoseconds\n", procBlock[message.i].timeBurst[0]);
			fflush(output);
			line++;
			if(procBlock[message.i].priority > 0 && procBlock[message.i].priority < 3)
				procBlock[message.i].priority += 1;
                        enqueue(queue[procBlock[message.i].priority], procBlock[message.i].pid);
                }		
	
		//check and wake block
		int x;
		for(x = 0; x < tabSize; x++){
			if(blockQueue[x] != 0){
				if ((procBlock[blockQueue[x]-1].blockedTo[1] == clock[1] 
				&& procBlock[blockQueue[x]-1].blockedTo[0] <= clock[0]) 
				|| procBlock[blockQueue[x]-1].blockedTo[1] < clock[1]){
					procBlock[blockQueue[x]-1].blocked = 0;
					fprintf(output,"OSS: waking process %i", procBlock[blockQueue[x]-1].pid); 
					fprintf(output," at %i:%i", clock[1], clock[0]);
					fflush(output);
					line++;
					clock[0] += 1000;
					timeConvert(clock);
					if (procBlock[blockQueue[x]-1].priority == 0){
						enqueue(queue[0], procBlock[blockQueue[x]-1].pid);
						fprintf(output," and placing in queue 0. This took 1000NS. \n");
					}
					else{
						enqueue(queue[1], procBlock[blockQueue[x]-1].pid);
						procBlock[blockQueue[x]-1].priority = 1;
						fprintf(output," and placing in queue 1 \n");
					}
					blockQueue[x] = 0;
				}
			}
		}

		//search queues for highest priority for dispatch	
		int index = -1;	
		for(x = 0; x < 4; x++){
			if((index = checkQueue(queue[x])) != -1){
				message.mesg_type = queue[x][index];
				break;
			}
		}

		//if there are no processes
		if (index == -1){
			message.first = 1;
			message.mesg_type = 1;
			if(msgsnd(msid, &message, sizeof(message), 0) == -1){
                        	perror("oss2: Error: msgsnd");
                	}
			continue;
		}
		
		//add work from user process and scheduler
		        clock[0] += 1000 + procBlock[message.i].timeBurst[0];
		        timeConvert(clock);

		//assign time slice
		message.slice = pow((double)2, (double)x) * q;

		fprintf(output, "OSS: Dispatching process with PID %i", queue[x][index]);
		fprintf(output, " from queue %i at time %i:%i", x, clock[1], clock[0]);
		fprintf(output, " with time slice of 0:%i. This took 1000NS\n", message.slice);
		fflush(output);
		line++;
	
		//queue output
		int j;
	        for(j = 0; j < 4; j++){
		for(i = 0; i < sizeof(pids)/sizeof(int); i++){
                        fprintf(queues,"%i ",queue[j][i]);
                }
		fprintf(queues,"\n");
		}	
		for(i = 0; i < sizeof(pids)/sizeof(int); i++){
			 fprintf(queues,"%i ",blockQueue[i]);
		}
		fprintf(queues,"\n\n");
	
		while(waitpid(-1, NULL, WNOHANG) != 0);

		dequeue(queue[x]);
		message.first = 0;		
	
		//send message to children
		if(msgsnd(msid, &message, sizeof(message), 0) == -1){
                	perror("oss2: Error: msgsnd");

	        }

	}


	if(prCount>=100){
		fprintf(output, "Terminating due to 100 processes being generated. \n");
	}

	//termination
	terminator();
	return 0;
}

void terminator(){

	//kill processes
	int i;
	fprintf(stderr, "oss %i SIGINT received \n", getpid());
	for(i = 0; i < sizeof(pids)/sizeof(int); i++){
		if(pids[i] != 0){
			kill(pids[i], SIGINT);
			prCount--;
		}
	}
	if(prCount > 0){
		fprintf(output, "Average turnaround time was:");
		Divide(averageLife);
		fprintf(output, "Average time slept was:");
		Divide(averageSleep);
		fprintf(output, "Average wait was:");
        	Divide(averageWait);
		fprintf(output, "Time spent with no processes %i:%09i. \n", idle[1], idle[0]);	
	}
	
	//wait and clear
	while(waitpid(-1, NULL, 0) != -1);
        shmctl(shmid, IPC_RMID, NULL);
        shmctl(procid, IPC_RMID, NULL);
        msgctl(msid, IPC_RMID, NULL);
}

void Divide(int usedAverage[]){
	double usedAverageD = (double)usedAverage[1];
        usedAverageD = usedAverageD/prCount;
        usedAverage[0] = usedAverage[0]/prCount;
        usedAverage[0] += (usedAverageD - (int)usedAverageD) * 1000000000;
        fprintf(output," %i:%i \n", (int)usedAverageD, usedAverage[0]);

}

int checkQueue(int queue[]){
	int j;
        for(j = 0; j < tabSize; j++){
		if (queue[j] != 0){
                        return j;
                }
	}
	return -1;
}

void dequeue(int queue[]){
 	int j;
        for(j = 0; j < tabSize-1; j++){
                queue[j] = queue[j+1];
        }
	queue[j] = 0;
}

void enqueue(int queue[], int pid){
	int j;
	for(j = 0; j < tabSize; j++){
		if (queue[j] == 0 || queue[j] == -1){
			queue[j] = pid;
			break;
		}
	}
}

void sigHandler(int signo){        
	if (signo == SIGINT || signo == SIGALRM){
		terminator();
		exit(0);
	}
}

void timeConvert(int clock[]){
        clock[1] += clock[0]/1000000000;
        clock[0] = clock[0]%1000000000;
}

static int setperiodic(double sec) {
   timer_t timerid;
   struct itimerspec value;
   if (timer_create(CLOCK_REALTIME, NULL, &timerid) == -1)
      return -1;
   value.it_interval.tv_sec = (long)sec;
   value.it_interval.tv_nsec = (sec - value.it_interval.tv_sec)*BILLION;
   if (value.it_interval.tv_nsec >= BILLION) {
      value.it_interval.tv_sec++;
      value.it_interval.tv_nsec -= BILLION;
   }
   value.it_value = value.it_interval;
   return timer_settime(timerid, 0, &value, NULL);
}





