#include <errno.h>
#include <stdlib.h>
#include <string.h>

int makeargv(const char *source, const char *delimiters, char ***argvp)
{
	int i;
	int error;
	int num_tokens;
	char *buf;
	const char *snew;

	if ((source == NULL) || (delimiters == NULL) || (argvp == NULL))
	{
		errno = EINVAL;
		return -1;
	}

	snew = source + strspn(source, delimiters);
	if ((buf = malloc(strlen(snew) + 1)) == NULL)
	{
		return -1;
	}
	strcpy(buf, snew);

	num_tokens = 0;
	if (strtok(buf, delimiters) != NULL)
	{
		for (num_tokens = 1; strtok(NULL, delimiters) != NULL; num_tokens++);
	}

	if ((*argvp = malloc((num_tokens + 1) * sizeof(char *))) == NULL)
	{
		error = errno;
		free(buf);
		errno = error;
		return -1;
	}

	if (num_tokens == 0)
	{
		free(buf);
	}
	else
	{
		strcpy(buf, snew);

		**argvp = strtok(buf, delimiters);
		for (i = 1; i < num_tokens; i++)
		{
			*((*argvp) + i) = strtok(NULL, delimiters);
		}
	}
	
	*((*argvp) + num_tokens) = NULL;

	return num_tokens;
}
