#include <stdio.h>
#include <unistd.h> //for getopt()
#include <sys/wait.h> // for wait()
#include <limits.h> //for maxcanon
#include "makeargv.h" //makeargv function

int main(int argc, char **argv)
{
	int pr_limit = 10;  //process limit
	int pr_count = 0;  //running processes
	char input[MAX_CANON];  //holds name of process to fan
	pid_t childpid;  //holds process code of child
	char delim[] = " \t\n"; //deliminators for makeargv func call
	char **margv; //hold strings made by makeargv

	//option handler
	int opt;
        while((opt = getopt (argc, argv, "n:h")) != -1)
                switch (opt){
                        case 'n':
				pr_limit =  atoi(optarg);
                                break;
                        case 'h':
				printf("This program spawns and counts child processes.\n");
				printf("-n option takes one argument and allows you to set a limit \n");
				printf("on how many children are running. If no limit is set the default is 10.");
				printf("This program will ask for the name \n");
				printf("of a program for it to spawn as children. \n");
				return 0;
                                break;}



	while(!feof(stdin)){  //loop ends when EOF is reached or entered

		//checks if process count has reached process limit.
		if(pr_count == pr_limit){
			wait(NULL);
			pr_count--;}

		//gets name of program to fan from command line
		if(!feof(stdin)){
			fgets(input, MAX_CANON, stdin);	
			input[strlen(input)] = '\0';}	
	
		//fork and check if fork was succesful
		pid_t childpid = fork();	
		if (childpid == -1) {
			perror("runsim: Error: Failed to fork");
 			return 1;}
		//succesful fork executes program
		if (childpid == 0) {
			if (makeargv(input, delim, &margv) == -1 ){
				perror("runsim: Error: failed to use makeargv");
				return 1;}
			execvp(margv[0], margv);
			perror("runsim: Error: execvp failed in child");
			return 1;}
		
		//check to see if any other process have finished.
		pr_count++;
		while(waitpid(-1, NULL, WNOHANG) != 0)
			pr_count--;
			
			
	}

	//wait for all remaining child process to end
	while (waitpid(-1, NULL, 0) != -1);
	printf("program finished.");

	return 0;
}
