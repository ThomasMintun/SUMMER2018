
#include<stdio.h>
#include<unistd.h>

int main(int argc, char **argv)
{
	//handle options
	int opt;
        while((opt = getopt (argc, argv, "n:h")) != -1)
                switch (opt){
                        case 'h':
				printf("This program runs a loop a specified number of times. \n");
				printf("In the loop the program will aleep a specified amount of time \n");
				printf("designated in seconds and then output the PID.\n");
				printf("This program requires two arguments. The first \n");
				printf("will set how long this program sleeps. The second determins how many times it loops.\n");
				return 0;
                                break;}

	//verify command line arguments
	if(argc < 3){
		perror("testsim: Error: Incorrect number of arguments.");
		return 1;}
	
	if(atoi(argv[1]) < 0 || atoi(argv[2]) < 0){
		perror("testsim: Error: Arguments must be integer greater than 0.");
		return 1;}

	//sleep loop
	int i;
	for(i = 0; i < atoi(argv[2]); i++){
		
		sleep(atoi(argv[1]));
		fprintf(stderr, "%i\n", getpid()); 
		
	}


	return 0;
}
